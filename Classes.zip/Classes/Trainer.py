from Database import DBHelper

class Trainer:
    def __init__(self, Name, UserName,UserType,Password):
        self.Name = Name
        self.UserName = UserName
        self.Password = Password
